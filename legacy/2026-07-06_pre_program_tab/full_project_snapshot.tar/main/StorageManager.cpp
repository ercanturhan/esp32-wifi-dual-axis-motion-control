#include "StorageManager.h"

StorageManager::StorageManager() {}

bool StorageManager::begin() {
    return _prefs.begin("stepper", false);
}

bool StorageManager::loadWifiConfig(WifiConfig& config) {
    size_t size = _prefs.getBytes("wifi_conf", &config, sizeof(WifiConfig));
    if (size != sizeof(WifiConfig)) {
        // Defaults: empty
        memset(&config, 0, sizeof(WifiConfig));
        // Save defaults
        return saveWifiConfig(config);
    }
    return true;
}

bool StorageManager::saveWifiConfig(const WifiConfig& config) {
    size_t size = _prefs.putBytes("wifi_conf", &config, sizeof(WifiConfig));
    return (size == sizeof(WifiConfig));
}

bool StorageManager::loadMotorConfig(int id, MotorConfig& config) {
    const char* key = (id == 1) ? "m1_conf" : "m2_conf";
    size_t size = _prefs.getBytes(key, &config, sizeof(MotorConfig));
    if (size != sizeof(MotorConfig)) {
        // Load default values
        config.maxSpeed = 2000.0f;
        config.acceleration = 1000.0f;
        config.minPosition = 0;
        config.maxPosition = (id == 1) ? 50000L : 100000L;
        
        config.stepAngle = 1.8f;
        config.microsteps = 16;
        config.driveType = DRIVE_LEAD_SCREW;
        config.leadScrewPitch = 8.0f;
        config.beltPitch = 2.0f;
        config.pulleyTeeth = 20;
        config.unitType = UNIT_MM;
        
        // Save default config
        return saveMotorConfig(id, config);
    }
    return true;
}

bool StorageManager::saveMotorConfig(int id, const MotorConfig& config) {
    const char* key = (id == 1) ? "m1_conf" : "m2_conf";
    size_t size = _prefs.putBytes(key, &config, sizeof(MotorConfig));
    return (size == sizeof(MotorConfig));
}

bool StorageManager::loadSystemConfig(SystemConfig& config) {
    size_t size = _prefs.getBytes("sys_conf", &config, sizeof(SystemConfig));
    if (size != sizeof(SystemConfig)) {
        config.enableTimeoutActive = true;
        config.enableTimeoutDuration = 10;
        config.motor1LastPos = 0;
        config.motor2LastPos = 0;
        return saveSystemConfig(config);
    }
    return true;
}

bool StorageManager::saveSystemConfig(const SystemConfig& config) {
    size_t size = _prefs.putBytes("sys_conf", &config, sizeof(SystemConfig));
    return (size == sizeof(SystemConfig));
}

bool StorageManager::savePositions(long pos1, long pos2) {
    SystemConfig config;
    if (loadSystemConfig(config)) {
        config.motor1LastPos = pos1;
        config.motor2LastPos = pos2;
        return saveSystemConfig(config);
    }
    return false;
}

void StorageManager::clearAll() {
    _prefs.clear();
}
